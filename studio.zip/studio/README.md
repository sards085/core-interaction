# Core Interaction — Final Project Boilerplate
Your final project for Core Studio should follow this structure, you may [clone](https://help.github.com/articles/cloning-a-repository/) it and use it as a boilerplate, or use this repo as a reference.  

[view the example](https://bryantwells.github.io/ci-studio-boilerplate/)
