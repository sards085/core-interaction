// PAGE SPECIFIC JS
// Delete this file if you don't need it

console.log('This is post 2.')
