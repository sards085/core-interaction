// GLOBAL JS
// JS from here should be applied to all pages
// Delete this file if you don't need it

console.log('Hello!')
